#ifndef __E2__
#define __E2__

long f(const short* v, unsigned n);
long f_opt(const short* v, unsigned n);

#endif
