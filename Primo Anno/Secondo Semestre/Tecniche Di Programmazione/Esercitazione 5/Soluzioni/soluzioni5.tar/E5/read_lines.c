
// Soluzione in 4.11
