from tester import tester_fun

def A_Ex1(s):
    d=''
    p=int(0)
    for i in range(len(s)):
        c=s[i]
        if s.count(c)>=p:
            p=s.count(c)
    for u in range(len(s)):
        b=s[u]
        if s.count(b)==p:
            if d.find(b)==-1:
                d+=b
    return (d)
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""


###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

"""SE NON VOLETE ESEGUIRE UN TEST COMMENTATE LA RIGA RELATIVA"""

counter_test_positivi = 0
total_tests = 5

counter_test_positivi += tester_fun(A_Ex1, ['caso palese'] ,'ase')
counter_test_positivi += tester_fun(A_Ex1, ['caso palesemente'] ,'e')
counter_test_positivi += tester_fun(A_Ex1, ['caso palese zitto'] ,'aso et')
counter_test_positivi += tester_fun(A_Ex1, ['aca'] ,'a')
counter_test_positivi += tester_fun(A_Ex1, [''] ,'')

print('La funzione',A_Ex1.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
