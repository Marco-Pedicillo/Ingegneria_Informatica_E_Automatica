from tester import tester_fun

def A_Ex6(s):
        t=0
        for i in s:
                if i.isupper() and i.isalpha():
                        r=s.count(i)
                        if int(t)<int(r):
                                t=r
        return (int(t))
                
        """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""
	
	
###############################################################################

"""NON MODIFICARE IL SEGUENTE CODICE (codice di test della funzione)"""

"""SE NON VOLETE ESEGUIRE UN TEST COMMENTATE LA RIGA RELATIVA"""

counter_test_positivi = 0
total_tests = 5

counter_test_positivi += tester_fun(A_Ex6, ['aHa^^&^HH'], 3)
counter_test_positivi += tester_fun(A_Ex6, [''], 0)
counter_test_positivi += tester_fun(A_Ex6, ['&&YH&Y'], 2)
counter_test_positivi += tester_fun(A_Ex6, ['stri%$p'], 0)
counter_test_positivi += tester_fun(A_Ex6, ['CIAO'], 1)

print('La funzione',A_Ex6.__name__,'ha superato',counter_test_positivi,'test su',total_tests)

###############################################################################

