def A_Ex10(i):
    t=[]
    for n in i:
        if n%5==0:
            t.append(n)
            t.sort()
    return (tuple(t))
    
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    """SE NON VOLETE ESEGUIRE UN TEST COMMENTATE LA RIGA RELATIVA CON #"""

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(A_Ex10, [{3,345,15,24,25,-10}], (-10,15,25,345))
    counter_test_positivi += tester_fun(A_Ex10, [set()], ())
    counter_test_positivi += tester_fun(A_Ex10, [{1,2,3}], ())
    counter_test_positivi += tester_fun(A_Ex10, [{5,10,0,-5,-10}], (-10,-5,0,5,10))
    counter_test_positivi += tester_fun(A_Ex10, [{100,50,-12,34,65}], (50,65,100))

    print('La funzione',A_Ex10.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
