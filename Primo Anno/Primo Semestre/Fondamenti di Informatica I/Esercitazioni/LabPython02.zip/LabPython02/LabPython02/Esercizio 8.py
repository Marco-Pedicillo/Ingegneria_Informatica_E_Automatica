c= int(input('inserisci età del cane: '))
anno1=anno2= 10.5

if c==1:
    print ('gli anni del cane in età umana sono: ',anno1)
elif c==2:
    print ('gli anni del cane in età umana sono: ',anno1+anno2)
elif c>2:
    print ('gli anni del cane in età umana sono: ', ((c-2)*4)+anno1+anno2)
