s= input('inserire una stringa non vuota: ')

if s[0]==s[-1]:
    print ('caratteri iniziale e finale uguali')
else:
    print('caratteri iniziale e finale diversi')
