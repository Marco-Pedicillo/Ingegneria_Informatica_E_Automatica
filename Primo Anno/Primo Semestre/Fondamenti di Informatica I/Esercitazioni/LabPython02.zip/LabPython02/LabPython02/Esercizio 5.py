n1= int(input('inserire un numero intero n1: '))
n2= int(input('inserire un numero intero n2: '))
n3= int(input('inserire un numero intero n3: '))

if n1>n2>n3:
    print ('\n',n1,'\n',n2,'\n',n3)
elif n1>n3>n2:
    print ('\n',n1,'\n',n3,'\n',n2)
elif n2>n1>n3:
    print ('\n',n2,'\n',n1,'\n',n3)
elif n2>n3>n1:
    print ('\n',n2,'\n',n3,'\n',n1)
elif n3>n1>n2:
    print ('\n',n3,'\n',n1,'\n',n2)
elif n3>n2>n1:
    print ('\n',n3,'\n',n2,'\n',n1)
