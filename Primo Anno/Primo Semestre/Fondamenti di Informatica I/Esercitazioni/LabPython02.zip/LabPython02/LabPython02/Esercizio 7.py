m= int(input('inserisci un mese: '))
a= int(input('inserisci un anno: '))

if 1<=m<12:
    print ((m+1),'/',a)
    
elif m==12:
    print (1,'/',(a+1))
    
else: print ('input non valido')
