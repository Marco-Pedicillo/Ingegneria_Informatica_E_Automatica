a=int(input('inserire un intero a: '))
b=int(input('inserire un intero b: '))
c=int(input('inserire un intero c: '))

if a>0 and b>0 and c>0 and a<b+c and b<a+c and c<a+b:
    if a==b and b==c and c==a:
        print ('equilatero')
    elif a==b!=c or b==c!=a or a==c!=b:
        print ('isoscele')
    elif a!=b and b!=c and c!=a:
        print ('scaleno')
else:
    print ('input non valido')
