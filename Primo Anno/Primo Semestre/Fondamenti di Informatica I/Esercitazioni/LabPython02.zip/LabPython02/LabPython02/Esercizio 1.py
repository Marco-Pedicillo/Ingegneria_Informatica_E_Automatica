hh= int(input('inserire numero di ore: '))
mm= int(input('inserire numero di minuti: '))
ss= int(input('inserire numero di secondi: '))

hh1= hh*3600
mm1= mm*60

print ('il numero totale di secondi è: ',hh1+mm1+ss)
