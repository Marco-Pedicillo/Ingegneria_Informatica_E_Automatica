t= float(input('inserisci una temperatura: '))
x= input('inserisci un carattere tra \'C\' e \'F\': ')

if x=='C' or x=='c':
    if t<=0:
        print ('solida')
    elif t>=100:
        print ('gassosa')
    else:
        print ('liquida')

elif x=='F' or x=='f':
    t=(t-32)/1.8
    print ('la temperatura in gradi Fahrenheit è: ',t)

    if t<=0:
        print ('solida')
    elif t>=100:
        print ('gassosa')
    else:
        print ('liquida')
