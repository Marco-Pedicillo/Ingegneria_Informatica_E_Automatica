def Ex3(file):
    f= open(file,'r',encoding='UTF-8')
    matr=[]
    conta=0
    massimo=0
    ris=0
    
    for elem in f:
        elem=elem.strip().split()
        matr.append(elem)
    righe= int(matr[0][0])+1
    colonne= int(matr[0][1])

    for i in range(1,righe):
        for j in range(colonne):
            n= int(matr[i][j])
            if n<0:
                conta+=1
        if conta>=massimo:
            massimo=conta
            ris=i-1
        conta=0

    return ris
                
        
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex3, ["matrice1.txt"] , 3)
    counter_test_positivi += tester_fun(Ex3, ["matrice2.txt"] , 0)
    counter_test_positivi += tester_fun(Ex3, ["matrice3.txt"] , 1)
    counter_test_positivi += tester_fun(Ex3, ["matrice4.txt"] , 3)
    counter_test_positivi += tester_fun(Ex3, ["matrice5.txt"] , 4)

    print('La funzione',Ex3.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
