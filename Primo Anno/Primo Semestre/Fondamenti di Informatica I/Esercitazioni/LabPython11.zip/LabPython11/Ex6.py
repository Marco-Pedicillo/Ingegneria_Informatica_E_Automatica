def Ex6(m):
    righe= len(m)
    colonne= len(m[0])
    ris=0

    for i in range(1,righe-1):
        for j in range(1,colonne-1):
            n=int(m[i][j])
            if n<=m[i-1][j-1] and n<=m[i-1][j] and n<=m[i-1][j+1]:
                if n<=m[i][j-1] and n<=m[i][j+1]:
                    if n<=m[i+1][j-1] and n<=m[i+1][j] and n<=m[i+1][j+1]:
                        ris+=1
    return (ris)
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex6, [[[3, 2, 0, 1], [4, 1, 2, 1], [2, 1, 3, 1], [2, 2, 2, 4], [3, 4, 2, 2]]] ,1)
    counter_test_positivi += tester_fun(Ex6, [[[3, 2, 0, 1, 2], [4, 1, 2, 1, 3], [2, 1, 3, 1, 1], [2, 2, 2, 4, 3], [3, 4, 2, 2, 2]]] , 2)
    counter_test_positivi += tester_fun(Ex6, [[[3, 2, 0], [3, 2, 3], [3, 2, 2], [2, 2, 4]]] , 1)
    counter_test_positivi += tester_fun(Ex6, [[[3, 2, 0, 1, 2, 2], [4, 1, 2, 1, 3, 2], [2, 1, 3, 1, 1, 4], [2, 2, 2, 4, 3, 3], [3, 4, 2, 2, 2, 4]]] ,3)
    counter_test_positivi += tester_fun(Ex6, [[[1]]] ,0)

    print('La funzione',Ex6.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
