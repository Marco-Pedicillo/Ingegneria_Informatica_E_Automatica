def Ex1(m):
    ris=0
    colonne= len(m[0])
    for i in m:
        conta=0
        for j in range(colonne):
            if i[j]==0:
                conta+=1
            else:
                conta=0
            if conta>ris:
                ris=conta
    return ris
    
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex1, [[[1,0,0,1,0],[0,0,0,1,0],[1,0,0,0,0],[1,1,1,0,0]]] , 4)
    counter_test_positivi += tester_fun(Ex1, [[[1,0,0,1,0],[0,0,0,1,0],[1,0,0,0,0],[1,1,0,0,0],[1,0,0,1,0]]] , 4)
    counter_test_positivi += tester_fun(Ex1, [[[1,0,0,1,0],[0,0,0,1,0],[1,0,1,0,0],[1,1,0,1,1],[1,0,0,1,0]]] , 3)
    counter_test_positivi += tester_fun(Ex1, [[[1,0,0,1,0],[0,0,0,1,0],[1,0,1,0,1],[1,1,0,1,0],[1,0,0,1,0]]] , 3)
    counter_test_positivi += tester_fun(Ex1, [[[1,0,0],[0,1,1],[1,0,1],[1,1,0]]] , 2)

    print('La funzione',Ex1.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
