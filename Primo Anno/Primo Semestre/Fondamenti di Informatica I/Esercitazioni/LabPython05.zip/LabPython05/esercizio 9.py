n=int(input('inserisci un intero: '))
s=' '
print('*'*n)

for i in range(2,n):
    print('*'+s*(n-2)+'*')

print('*'*n)
