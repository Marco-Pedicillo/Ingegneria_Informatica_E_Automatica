n1=int(input('inserisci un intero positivo: '))
n2=int(input('inserisci un intero positivo: '))

x=1

while n1>0 and n2>0:
    print(n1*x)
    x+=1
    if (n1*x)>=n2:
        break
    
