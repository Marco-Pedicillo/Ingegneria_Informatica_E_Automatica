n=int(input('inserisci un intero: '))
s=' '

for i in range(n+1):
    if i%2!=0:
        print(s*(n)+'*'*i)
        n-=1
