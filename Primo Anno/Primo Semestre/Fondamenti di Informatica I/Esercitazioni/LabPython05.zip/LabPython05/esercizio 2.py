s=input('inserisci una stringa: ')
n=int(input('inserisci un intero: '))

if n>0:
    for i in range(len(s)):
        print(s[i]*n,end='')

else:
    print('numero non positivo')
