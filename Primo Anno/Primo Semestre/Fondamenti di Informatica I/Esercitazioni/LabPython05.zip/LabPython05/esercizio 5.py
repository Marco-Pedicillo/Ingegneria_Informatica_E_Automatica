s=input('inserisci una stringa: ')
n=int(input('inserisci un intero: '))

x=0

for i in range(len(s)-n):
    if s[i]==s[i+n]:
        x+=1

    
if x>0:
    print (True)
else:
    print(False)
