s1=input('inserisci una stringa: ')
s2=input('inserisci una stringa: ')
#devono avere la stessa lunghezza

t=''

if len(s1)==len(s2):
    for i in range(len(s1)):
        t+=(s1[i]+s2[i])
    print(t)
else:
    print('lunghezze diverse')
