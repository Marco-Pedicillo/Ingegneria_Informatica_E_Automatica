n=int(input('inserisci un intero: '))

for i in range(n):
    for t in range(n):
        if t==0:
            print('*',end='')
        elif t==n-1:
            print('*')
        else:
            if i==0 or i==n-1:
                print('*',end='')
            else:
                if i==t or i==n-(t+1):
                    print('*',end='')
                else:
                    print(' ',end='')
