s=input('inserisci una stringa: ')
t=0

for i in range (0,len(s)):
    if t+i<s.rfind(s[i]):
        t=s.rfind(s[i])
print (t)
