s = input('inserisci una stringa: ')
b = False
for i in s:
   if s.count(i)>1:
      b = True
if b:
   print("True")
else:
   print("False")
