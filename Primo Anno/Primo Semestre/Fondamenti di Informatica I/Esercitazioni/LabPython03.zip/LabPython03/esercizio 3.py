n = int(input("Inserire una sequenza di numeri interi: "))
while n%5!=0:
    n = int(input("Inserire un altro numero intero: "))
print(int(n/5))
