s=input('inserisci una stringa: ')
t=1
i=0
while t:
    if ord(s[i])> 100:
        print ('Il primo carattere con codice Unicode maggiore di 100 è: ' ,s[i])
        t=0
    elif i== len(s)-1:
        print ('stringa consumata e carattere non trovato')
        t=0
    i+=1
