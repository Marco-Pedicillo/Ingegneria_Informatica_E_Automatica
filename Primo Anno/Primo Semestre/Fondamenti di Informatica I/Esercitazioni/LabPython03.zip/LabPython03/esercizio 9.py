n=int(input('inserisci un numero primo: '))
i=2
max= ((n//2)+1)
while i<max:
    if n%i==0:
        i=max
    i+=1
if i==max+1:
    print ('numero non primo')
else:
    print ('numero primo')
