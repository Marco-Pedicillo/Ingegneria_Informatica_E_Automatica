n=int(input('inserisci un intero maggiore di 1: '))
i=2
t=2
while i<n:
    while t<=i:
        if i == t:
            print(i)
        elif i%t==0:
            t=i
        t+=1
    t=2
    i+=1
