n= int(input('inserisci un intero maggiore di 2: '))
s=0
while n>=2:
    if n%2==0:
        print (n)
        n=n-1
    elif n%2!=0:
        n=n-1
