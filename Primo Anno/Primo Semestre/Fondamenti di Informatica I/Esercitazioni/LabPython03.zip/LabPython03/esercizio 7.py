c=input('inserisci un carattere: ')
s=input('inserisci una stringa: ')
while int(s.count(c))<3:
    s=input('inserisci una stringa: ')
print (s.count(c))
