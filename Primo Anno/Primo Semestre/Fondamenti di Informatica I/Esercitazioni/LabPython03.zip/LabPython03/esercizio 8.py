s = str(input("Inserire una stringa palindroma: "))
x = True
while x:
    if s==s[::-1]:
        print("stringa palindroma di lunghezza",len(s))
        x = False 
    else:
        s = str(input("non palindroma, inserire una stringa palindroma: "))
