n=int(input('inserisci un intero > 0: '))
div=1
while div<=n:
    if n%div==0:
        print (div)
        div=div+1
    elif n%div!=0:
        div=div+1
