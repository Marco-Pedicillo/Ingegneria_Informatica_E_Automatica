a= True
while a:
    s=input('inserisci una stringa: ')
    if not s.isalpha() or not s.islower():
        print (s[0]+s[-1])
        
    elif s.isalpha() and s.islower():
        a= False
        print (s[0]+s[-1])
