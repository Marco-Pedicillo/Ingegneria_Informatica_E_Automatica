x=int(input('inserisci un numero compreso tra 0 e 10: '))
y=int(input('inserisci un numero compreso tra 0 e 10: '))

z=0
while z<=10:
    if z==x or z==y:
        z=z+1
    else:
        print (z)
        z=z+1
