def Ex3(file1,file2):
    d={}
    ris={}
    
    f1= open(file1,'r', encoding= 'UTF-8')
    for riga in f1:
        riga=riga.strip().split(',')
        piatto= riga[0].strip()
        costo= int(riga[1])
        disp= int(riga[2])

        d[piatto]= []
        d[piatto].append(costo)
        d[piatto].append(disp)

    f2= open(file2,'r', encoding= 'UTF-8')
    for riga1 in f2:
        riga1= riga1.strip().split(',')
        cliente= riga1[0].strip()
        ris[cliente]= 0

        x= True
        for i in range(1,len(riga1)):
            r= riga1[i].split(':')
            if x:
                if r[0] in d:
                    print (d[r[0]][1],riga[2])
                    if int (d[r[0]][1]) >= int(r[1]):
                        ris[riga1[0]] += int(d[r[0]][0])*int(r[1])
                        d[r[0]][1]= int(d[r[0]][1]) - (int(r[1]))
                    else:
                        ris[riga1[0]]= 'respinto'
                        x= False
                        break
                else:
                    ris[riga1[0]]= 'respinto'
                    x= False
                    break

    return ris
        
        
    
        
        
        
        
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""    
###############################################################################

"""NON MODIFICARE IL CODICE (codice di test della funzione)"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex3, ['menu1.csv','ordini1.csv'],{'Giorgio': 68, 'Paola': 'respinto', 'Francesca': 66})
    counter_test_positivi += tester_fun(Ex3, ['menu1.csv','ordini2.csv'],{'Giorgio': 68, 'Paola': 'respinto', 'Francesca': 66, 'Daniele': 36})
    counter_test_positivi += tester_fun(Ex3, ['menu2.csv','ordini3.csv'],{'Giorgio': 68, 'Paola': 'respinto', 'Francesca': 66, 'Daniele': 36, 'Fabio': 'respinto'})
    counter_test_positivi += tester_fun(Ex3, ['menu3.csv','ordini7.csv'],{'Giorgio': 'respinto', 'Paola': 'respinto', 'Francesca': 'respinto', 'Filippo': 'respinto'})
    counter_test_positivi += tester_fun(Ex3, ['menu3.csv','ordini9.csv'],{'Giorgio': 'respinto', 'Paola': 'respinto', 'Luca': 'respinto', 'Gino': 30})

    print('La funzione',Ex3.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
