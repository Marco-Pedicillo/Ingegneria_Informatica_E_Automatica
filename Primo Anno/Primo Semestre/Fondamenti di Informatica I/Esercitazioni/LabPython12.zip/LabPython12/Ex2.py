def Ex2(i,file):
    import re
    ris= {}
    
    pattern= r'(\+|00)([0-9][0-9]*[0-9]*)-*([0-9][0-9][0-9])-*([0-9][0-9][0-9][0-9][0-9])'

    l= list(i)
    for j in range(len(l)):
        x= l[j]
        ris[x]= 0

    f= open(file,'r',encoding='UTF-8')
    f=f.read()
    m= re.finditer(pattern, f)
    for r in m:
        for k in ris:
            if int(r.group(2)) == int(k):
                ris[k] += 1

    return ris

    
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""        
            
###############################################################################

"""NON MODIFICARE IL CODICE (codice di test della funzione)"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex2, [{'39','351','34'},'testo1.txt'],{'39':2,'351':1,'34':0})
    counter_test_positivi += tester_fun(Ex2, [{'1','351'},'testo2.txt'],{'1':3,'351':1})
    counter_test_positivi += tester_fun(Ex2, [{'39','351','34','1'},'testo3.txt'],{'1':0,'351':0,'34':0,'39':2})
    counter_test_positivi += tester_fun(Ex2, [{'39','44','661','9'},'testo6.txt'],{'661': 1, '39': 2, '9': 1, '44': 2})
    counter_test_positivi += tester_fun(Ex2, [set(),'testo6.txt'],{})
    
    print('La funzione',Ex2.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
