n=int(input('inserisci un intero: '))
prec=1
succ=1
somma=0
i=3
if n==1 and n==2:
    print (1)
elif n>2:
    print(prec)
    print(succ)
    while i<=n:
        somma=prec+succ
        print (somma)
        prec=succ
        succ=somma
        i+=1
