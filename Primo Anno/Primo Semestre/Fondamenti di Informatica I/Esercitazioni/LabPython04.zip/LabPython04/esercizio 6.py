n1=int(input('inserire un primo intero: '))
n2=int(input('inserire un secondo intero: '))
prodotto=0

while n2>=1:
    prodotto+=n1
    n2-=1
print (prodotto)
