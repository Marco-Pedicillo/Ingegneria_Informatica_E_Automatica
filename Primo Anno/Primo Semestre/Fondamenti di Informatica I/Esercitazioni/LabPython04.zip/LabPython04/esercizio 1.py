s=input('inserire una stringa: ')
n=1
while 'a' and 'c' not in (s):
    s=input('inserire una stringa: ')
    n+=1
print(n)
