n=int(input('inserisci un intero: '))
if n%3==0:
    i=n

while n!=0:
    n=int(input('inserisci un intero: '))
    if n%3==0:
        i+=n
print (i)
    
    
