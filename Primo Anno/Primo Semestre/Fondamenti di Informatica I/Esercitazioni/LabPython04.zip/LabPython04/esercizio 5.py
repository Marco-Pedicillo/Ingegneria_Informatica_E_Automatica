n=int(input('inserire un intero maggiore o uguale a 0: '))
f=1
i=0

if n==0 or n==1:
    print (f)
elif n>0:
    while i<n:
        f=f*(n-i)
        i+=1
        print (f)
