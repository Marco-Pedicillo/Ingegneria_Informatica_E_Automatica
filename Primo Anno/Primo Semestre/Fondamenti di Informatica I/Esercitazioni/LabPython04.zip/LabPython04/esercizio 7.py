s=input('inserire una stringa: ')
x=s.count(s[0])
y=s[0]
i=1
while i<len(s):
    if s.count(s[i])>=x:
        x=s.count(s[i])
        y=s[i]
        i+=1
    else:
        i+=1
print(y)
