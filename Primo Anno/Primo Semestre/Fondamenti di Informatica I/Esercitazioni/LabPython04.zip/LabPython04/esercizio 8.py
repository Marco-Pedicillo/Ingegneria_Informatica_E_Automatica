s=input('inserisci una stringa: ')
sb=''
i=0

while not i:
    sb=s
    s=input('inserisci una stringa: ')
    if s[0]==sb[-1]:
        i=1
print (sb,s)
