n=int(input('inserisci un intero: '))

if n>0:
    i=1
elif n<0:
    i=0

while n!='*':
    n=input('inserisci un intero: ')
    if n!='*':
        n=int(n)
        if n>0:
            i+=1
        else:
            i=i
print (i)
    
