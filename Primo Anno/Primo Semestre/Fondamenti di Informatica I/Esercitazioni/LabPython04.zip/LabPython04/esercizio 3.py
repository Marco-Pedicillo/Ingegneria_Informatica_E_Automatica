n=input('inserisci un intero: ')
s=0
if n!='*' and int(n)<0:
    s=int(n)
while n!='*':
    n=input('inserisci un intero: ')
    if n!='*' and int(n)<0:
        s+=int(n)
print (s)
