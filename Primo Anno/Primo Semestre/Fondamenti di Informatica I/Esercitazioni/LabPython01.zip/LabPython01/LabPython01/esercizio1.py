var1= int(input('inserisci un intero '))
var2= var1**2
print ('il suo quadrato è: ',var2)
