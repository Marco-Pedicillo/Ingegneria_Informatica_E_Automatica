x= input('inserire un carattere qualunque ')
n= int(input('inserire un intero positivo '))
print ((x*n+'\n')*n)
