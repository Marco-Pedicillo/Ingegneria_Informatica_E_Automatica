var1= int(input('inserisci un intero '))
var2= int(input('inserisci un altro intero '))
var3= var1/var2
print (var3)
