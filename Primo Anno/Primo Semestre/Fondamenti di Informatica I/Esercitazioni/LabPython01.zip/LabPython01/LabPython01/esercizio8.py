s= input('inserire una stringa ')
n= int(input('inserire un intero '))
print ('la stringa ripetuta \'n\' volte è: ',(s*n))
