var1= int(input('inserisci un intero '))
var2= int(input('inserisci un altro intero '))
var3= var2/var1
print (var3)
