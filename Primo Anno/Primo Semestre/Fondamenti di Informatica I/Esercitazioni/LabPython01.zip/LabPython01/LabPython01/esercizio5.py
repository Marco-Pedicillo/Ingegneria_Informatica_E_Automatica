s= input('inserire una stringa ')
s1= input("inserire un'altra stringa ")
s3= s+' '+s1
print (s3)
