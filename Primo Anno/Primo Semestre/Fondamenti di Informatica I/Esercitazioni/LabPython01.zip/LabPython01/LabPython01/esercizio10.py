x= input('inserire un carattere qualunque ')
print ((((x+' ')*3) +'\n')*3)
