a=int(input('inserire il primo intero '))
b=int(input('inserire il secondo intero '))
c=int(input('inserire il terzo intero '))

from math import sqrt
delta= sqrt (b**2-4*a*c)

x1= int((-b+delta)/(2*a))
x2= int((-b-delta)/(2*a))

print ("le soluzioni dell'equazione sono: ",(x1,x2))
