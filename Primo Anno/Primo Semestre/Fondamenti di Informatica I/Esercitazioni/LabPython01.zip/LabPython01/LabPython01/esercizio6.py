s= input('inserire una stringa ')
i= int(input('inserire un intero '))
print (s[i])
