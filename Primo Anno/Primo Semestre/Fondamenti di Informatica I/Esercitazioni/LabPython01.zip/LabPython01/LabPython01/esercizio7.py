s= input('inserire una stringa ')
s1= input("inserire un'altra stringa ")
print('la somma delle loro lunghezze è: ',len(s+s1))
