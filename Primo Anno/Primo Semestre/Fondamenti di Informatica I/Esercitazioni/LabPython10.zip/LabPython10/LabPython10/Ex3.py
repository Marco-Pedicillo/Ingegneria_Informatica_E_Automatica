import re

def Ex3(file):
    f= open(file,'r',encoding='UTF-8')
    
    pattern= r'(\w)\w*(\w)\2\w*\1'
    r=0

    for riga in f:
        i=re.findall(pattern, riga , re.IGNORECASE)
        r+= len(i)

    return (r)
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

 
###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex3, ["file3_1.txt"] , 3)
    counter_test_positivi += tester_fun(Ex3, ["file3_2.txt"] , 3)
    counter_test_positivi += tester_fun(Ex3, ["file3_3.txt"] , 2)
    counter_test_positivi += tester_fun(Ex3, ["file3_4.txt"] , 4)
    counter_test_positivi += tester_fun(Ex3, ["file3_5.txt"] , 4)

    print('La funzione',Ex3.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
