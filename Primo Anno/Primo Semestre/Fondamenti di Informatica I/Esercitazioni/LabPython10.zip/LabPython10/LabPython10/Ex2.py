import re

def Ex2(file):
    f= open(file,'r',encoding='UTF-8')
    f1= f.readlines()
    f.close
    r=0

    for riga in f1:
        pattern= r'\b\w*(\w)\1\w*\b\W+\b\w*\1\1\w*\b\W+\b\w*\1\1\w*\b'
        t=re.findall(pattern ,riga ,re.IGNORECASE)
        r+=len(t)

    return (r)
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex2, ["file2_1.txt"] , 1)
    counter_test_positivi += tester_fun(Ex2, ["file2_2.txt"] , 2)
    counter_test_positivi += tester_fun(Ex2, ["file2_3.txt"] , 3)
    counter_test_positivi += tester_fun(Ex2, ["file2_4.txt"] , 4)
    counter_test_positivi += tester_fun(Ex2, ["file2_5.txt"] , 5)

    print('La funzione',Ex2.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
