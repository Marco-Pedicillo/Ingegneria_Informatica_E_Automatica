def Ex5(file):
    file= open(file,'r',encoding='UTF-8')
    d= {'invalidi':0, 'domestici':0, 'altri':0}

    for riga in file:
        r= riga.strip().split('.')
        if 1<= len (r[0])<=3 and 1<= len(r[1])<=3 and 1<= len(r[2])<=3 and 1<= len(r[3])<=3:
            if 0<= int(r[0])<=255 and 0<= int(r[1])<=255 and 0<= int(r[2])<=255 and 0<= int(r[3])<=255:
                if r[0] == '192' and r[1] == '168':
                    d['domestici']+=1
                else:
                    d['altri']+=1
            else:
                d['invalidi']+=1
        else:
            d['invalidi']+=1

    return (d)
    """MODIFICARE IL CONTENUTO DI QUESTA FUNZIONE PER SVOLGERE L'ESERCIZIO"""

    
###############################################################################

"""NON MODIFICARE, codice di testing della funzione"""

if __name__ == '__main__':
    from tester import tester_fun

    counter_test_positivi = 0
    total_tests = 5

    counter_test_positivi += tester_fun(Ex5, ["ip1.txt"] , {'invalidi': 0, 'domestici': 0, 'altri': 5})
    counter_test_positivi += tester_fun(Ex5, ["ip2.txt"] , {'invalidi': 2, 'domestici': 1, 'altri': 2})
    counter_test_positivi += tester_fun(Ex5, ["ip3.txt"] , {'invalidi': 1, 'domestici': 1, 'altri': 3})
    counter_test_positivi += tester_fun(Ex5, ["ip4.txt"] , {'invalidi': 1, 'domestici': 1, 'altri': 3})
    counter_test_positivi += tester_fun(Ex5, ["ip5.txt"] , {'invalidi': 3, 'domestici': 0, 'altri': 2})

    print('La funzione',Ex5.__name__,'ha superato',counter_test_positivi,'test su',total_tests)
